# Linux Wwise Unity Build module
import BuildUtil
import BuildWwiseUnityIntegration
import GenerateApiBinding
import platform
import os
from os import path
from BuildWwiseUnityIntegration import MultiArchBuilder
from GenerateApiBinding import GccSwigCommand
from PrepareSwigInput import SwigPlatformHandlerPOSIX, SwigApiHeaderBlobber, PlatformStructProfile

class LinuxBuilder(MultiArchBuilder):
	def __init__(self, platformName, arches, configs, generateSwig, generatePremake):
		MultiArchBuilder.__init__(self, platformName, arches, configs, generateSwig, generatePremake)
		self.compiler = 'make'
		self.solution = 'AkSoundEngineLinux.make'

	def _CreateCommands(self, arch=None, config='Profile'):
		if platform.system() == 'Windows':
			return []
		
		configString = 'config=' + config.lower() + '_' + 'x64'
		chrootPlat = 'steamrt_scout_amd64'
		
		cmd = ['schroot', '--chroot', chrootPlat, '--', self.compiler, '-f', self.solution, configString]
		return [cmd]

	def _RunCommands(self, cmds):
		previous_cwd = os.getcwd()
		os.chdir('../Linux')
		isSuccess = MultiArchBuilder._RunCommands(self, cmds)
		os.chdir(previous_cwd)
		return isSuccess
		
class LinuxSwigCommand(GccSwigCommand):
	def __init__(self, pathMan):
		GccSwigCommand.__init__(self, pathMan)
		self.compilerDefines += ['-D__linux__']
		self.platformDefines += ['-DAK_LINUX']
	
class SwigApiHeaderBlobberLinux(SwigApiHeaderBlobber):
	def __init__(self, pathMan):
		SwigApiHeaderBlobber.__init__(self, pathMan)

		self.inputHeaders.append(path.normpath(path.join(self.SdkIncludeDir, 'AK/SoundEngine/Platforms/Linux/AkLinuxSoundEngine.h')))

class SwigPlatformHandlerLinux(SwigPlatformHandlerPOSIX):
	def __init__(self, pathMan):
		SwigPlatformHandlerPOSIX.__init__(self, pathMan)
		ThreadPropertyHeader = 'AK/Tools/Linux/AkPlatformFuncs.h'

def Init(argv=None):
	BuildUtil.BankPlatforms['Linux'] = 'Linux'
	BuildUtil.SupportedArches['Linux'] = ['x86_64']
	BuildUtil.PremakeParameters['Linux'] = { 'os': 'linux', 'generator': 'gmake' }
	BuildUtil.PlatformSwitches['Linux'] = '#if UNITY_STANDALONE_LINUX && ! UNITY_EDITOR'
	BuildUtil.SupportedPlatforms['Windows'].append('Linux')
	BuildUtil.SupportedPlatforms['Linux'].append('Linux')

def CreatePlatformBuilder(platformName, arches, configs, generateSwig, generatePremake):
	return LinuxBuilder(platformName, arches, configs, generateSwig, generatePremake)

def CreateSwigCommand(pathMan, arch):
	return LinuxSwigCommand(pathMan)

def CreateSwigPlatformHandler(pathMan):
	return SwigPlatformHandlerLinux(pathMan)

def CreateSwigApiHeaderBlobber(pathMan):
	return SwigApiHeaderBlobberLinux(pathMan)

if __name__ == '__main__':
	pass
